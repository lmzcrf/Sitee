@echo off
set RB_ADMIN_EMAIL=dona@rbacademia.local
set RB_ADMIN_PASSWORD=Troque123!
set PORT=3000
node server.js
pause
