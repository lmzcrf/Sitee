# Publicar no GitHub e usar no Android

## 1. GitHub
- Crie um repositório **privado** para o código da academia.
- Suba o projeto sem o arquivo `data/rb-academia.db`.
- Não publique `.env` nem chaves.

## 2. Backend
GitHub Pages é hospedagem de arquivos estáticos e não executa `server.js`. Para o sistema completo, publique o Node em Render, Railway ou VPS. O arquivo `render.yaml` já deixa a estrutura inicial para Render.

## 3. Banco de produção
O protótipo usa SQLite. Em hospedagem sem disco persistente, migre o banco para PostgreSQL/Supabase antes de cadastrar dados reais. O objetivo é que pagamentos, avaliações e dados pessoais não dependam do disco efêmero do servidor.

## 4. Android
Com o site publicado em HTTPS:
- Abra a URL no Chrome Android.
- Menu ⋮ → **Adicionar à tela inicial** ou **Instalar app**.
- O manifest + service worker permitem a experiência de PWA.

## 5. Privacidade
Use HTTPS, senhas fortes, segredo de IA somente no servidor, backups do banco e permissões mínimas. Nunca coloque senha da dona ou token do WhatsApp em arquivos públicos do GitHub.
