# Checklist de produção

1. Hospedar atrás de HTTPS.
2. Usar senha forte para a conta da dona e rotacioná-la.
3. Definir `NODE_ENV=production` e variáveis em secret manager.
4. Fazer backup diário do SQLite; para escala maior, migrar para PostgreSQL.
5. Adicionar rate limit no login e CSRF se houver operações cross-site.
6. Integrar WhatsApp Business por provedor oficial; nunca automatizar via conta pessoal de forma não autorizada.
7. Adicionar consentimento e política de privacidade, especialmente para dados de saúde/avaliação física.
8. Manter logs de auditoria para alterações administrativas.
9. Separar permissões futuras: admin, personal, financeiro e aluno.
10. Não colocar tokens, senhas, chaves de IA ou credenciais de pagamento no frontend.
