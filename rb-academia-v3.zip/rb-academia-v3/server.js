const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA = path.join(ROOT, 'data');
fs.mkdirSync(DATA, { recursive: true });
const db = new DatabaseSync(path.join(DATA, 'rb-academia.db'));
db.exec(`PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('aluno','admin')) DEFAULT 'aluno',
 active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
 token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at INTEGER NOT NULL,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS profiles (
 user_id INTEGER PRIMARY KEY, phone TEXT DEFAULT '', birth_date TEXT DEFAULT '', goal TEXT DEFAULT 'Condicionamento',
 weight REAL DEFAULT 0, height REAL DEFAULT 0, notes TEXT DEFAULT '',
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS workouts (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, title TEXT NOT NULL,
 objective TEXT DEFAULT '', exercises_json TEXT NOT NULL DEFAULT '[]', updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS attendance (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, checkin_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS payments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, amount REAL NOT NULL DEFAULT 0,
 due_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pendente', paid_at TEXT,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS announcements (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS evaluations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, weight REAL DEFAULT 0, waist REAL DEFAULT 0, hip REAL DEFAULT 0, notes TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS exercises (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, muscle_group TEXT DEFAULT '', video_url TEXT DEFAULT '', instructions TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS automations (
 key TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS calendar_events (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, title TEXT NOT NULL, event_date TEXT NOT NULL, notes TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);`);

const ADMIN_EMAIL = process.env.RB_ADMIN_EMAIL || '';
const ADMIN_PASSWORD = process.env.RB_ADMIN_PASSWORD || '';
if (ADMIN_EMAIL && ADMIN_PASSWORD) {
  const exists = db.prepare('SELECT id FROM users WHERE email=?').get(ADMIN_EMAIL.toLowerCase());
  if (!exists) {
    const hash = hashPassword(ADMIN_PASSWORD);
    const r = db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,\'admin\')').run('Administradora RB Academia', ADMIN_EMAIL.toLowerCase(), hash);
    db.prepare('INSERT INTO profiles(user_id,goal) VALUES(?,?)').run(Number(r.lastInsertRowid), 'Gestão');
  }
}


const seedExercises=[
 ['Agachamento','Pernas','https://www.youtube.com/results?search_query=agachamento+técnica','Pés firmes, joelhos acompanhando a direção dos pés e amplitude confortável.'],
 ['Supino','Peito','https://www.youtube.com/results?search_query=supino+técnica','Escápulas estáveis, punhos alinhados e movimento controlado.'],
 ['Remada','Costas','https://www.youtube.com/results?search_query=remada+técnica','Coluna neutra, ombros controlados e sem puxar com impulso.'],
 ['Puxada frontal','Costas','https://www.youtube.com/results?search_query=puxada+frontal+técnica','Controle a subida e evite usar balanço excessivo.']
];
for(const ex of seedExercises){if(!db.prepare('SELECT id FROM exercises WHERE name=?').get(ex[0]))db.prepare('INSERT INTO exercises(name,muscle_group,video_url,instructions) VALUES(?,?,?,?)').run(...ex);}
function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `scrypt$${salt}$${derived}`;
}
function verifyPassword(password, stored) {
  const [kind, salt, expected] = String(stored).split('$');
  if (kind !== 'scrypt' || !salt || !expected) return false;
  const actual = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(actual, 'hex'), Buffer.from(expected, 'hex'));
}
function tokenHash(token) { return crypto.createHash('sha256').update(token).digest('hex'); }
function parseCookies(req) { return Object.fromEntries(String(req.headers.cookie||'').split(';').map(v=>v.trim()).filter(Boolean).map(v=>{const i=v.indexOf('=');return [decodeURIComponent(v.slice(0,i)),decodeURIComponent(v.slice(i+1))]})); }
function sessionUser(req) {
  const token = parseCookies(req).rb_session;
  if (!token) return null;
  const row = db.prepare(`SELECT u.id,u.name,u.email,u.role,u.active FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?`).get(tokenHash(token), Date.now());
  return row && row.active ? row : null;
}
function json(res, status, data, extra={}) { const body=JSON.stringify(data); res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...extra}); res.end(body); }
function readBody(req) { return new Promise((resolve,reject)=>{let d=''; req.on('data',c=>{d+=c;if(d.length>500000) req.destroy();});req.on('end',()=>{try{resolve(d?JSON.parse(d):{})}catch(e){reject(e)}});req.on('error',reject)}); }
function requireAuth(req,res,role) { const u=sessionUser(req); if(!u){json(res,401,{ok:false,error:'Não autenticado'});return null} if(role && u.role!==role){json(res,403,{ok:false,error:'Acesso restrito à administração'});return null} return u; }
function cleanEmail(v){return String(v||'').trim().toLowerCase()}
function publicUser(u){return {id:u.id,name:u.name,email:u.email,role:u.role}}

async function aiReply(user, message) {
  const text = String(message||'').trim().slice(0,3000);
  if (!text) return 'Me diga o que você precisa. Posso ajudar com treino, exercícios, evolução, rotina, frequência e dúvidas gerais.';
  if (process.env.AI_API_KEY && process.env.AI_API_URL) {
    try {
      const ctx=dashboardData(user); const recent=db.prepare('SELECT weight,waist,hip,created_at FROM evaluations WHERE user_id=? ORDER BY id DESC LIMIT 5').all(user.id); const prompt = `Você é a RB IA da RB Academia. Ajude com educação sobre treino de forma segura. Não diagnostique doenças, não prescreva medicamentos e não substitua a personal. Explique exercícios com técnica, aquecimento, progressão e sinais para parar. Você pode usar somente os dados abaixo e deve evitar expor dados desnecessários. Aluno: ${user.name}. Objetivo: ${ctx.profile?.goal||'não informado'}. Peso: ${ctx.profile?.weight||'não informado'} kg. Altura: ${ctx.profile?.height||'não informado'} cm. Check-ins: ${ctx.attendance||0}. Treino: ${ctx.workout?.title||'não cadastrado'}. Avaliações recentes: ${JSON.stringify(recent)}.`;
      const r = await fetch(process.env.AI_API_URL, {method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.AI_API_KEY}`},body:JSON.stringify({model:process.env.AI_MODEL||'gpt-4o-mini',messages:[{role:'system',content:prompt},{role:'user',content:text}],temperature:0.4})});
      if(r.ok){const j=await r.json();const out=j.choices?.[0]?.message?.content;if(out)return out;}
    } catch(e) {}
  }
  const q=text.toLowerCase();
  if(q.includes('agach')) return 'No agachamento: mantenha o pé firme, joelhos acompanhando a direção dos pés, tronco controlado e desça apenas até uma amplitude confortável. Comece com carga leve e peça à personal para conferir sua técnica. Se houver dor aguda, pare.';
  if(q.includes('supino')) return 'No supino: escápulas estáveis, pés apoiados, punhos alinhados e movimento controlado. Use carga compatível com sua técnica e tenha supervisão/apoio quando necessário. Dor não é um objetivo do exercício.';
  if(q.includes('treino') || q.includes('exerc')) return 'Posso explicar a execução, sugerir uma organização geral e ajudar a acompanhar seu treino. Para alterar sua ficha individual, a personal deve revisar volume, carga e objetivo.';
  if(q.includes('faltar') || q.includes('frequ')) return 'Regularidade importa. Confira sua frequência no painel e combine uma rotina realista. Se você estiver com dor, febre ou mal-estar, priorize sua saúde e procure orientação adequada.';
  return `Entendi, ${user.name.split(' ')[0]}. Posso ajudar com execução de exercícios, organização do treino, hábitos, frequência e acompanhamento. Para decisões individualizadas de carga ou mudanças na ficha, confirme com a personal da RB Academia.`;
}

function dashboardData(u){
  const profile=db.prepare('SELECT phone,birth_date,goal,weight,height,notes FROM profiles WHERE user_id=?').get(u.id)||{};
  const workout=db.prepare('SELECT id,title,objective,exercises_json,updated_at FROM workouts WHERE user_id=? ORDER BY id DESC LIMIT 1').get(u.id);
  const attendance=db.prepare('SELECT COUNT(*) c FROM attendance WHERE user_id=?').get(u.id)?.c||0;
  const payment=db.prepare('SELECT amount,due_date,status,paid_at FROM payments WHERE user_id=? ORDER BY id DESC LIMIT 1').get(u.id)||null;
  return {user:publicUser(u),profile,workout:workout?{...workout,exercises:JSON.parse(workout.exercises_json||'[]')}:null,attendance,payment};
}

async function api(req,res,url){
  const method=req.method;
  if(url==='/api/health'&&method==='GET') return json(res,200,{ok:true,service:'RB Academia',db:'sqlite',node:process.version});
  if(url==='/api/auth/register'&&method==='POST'){
    const b=await readBody(req);const name=String(b.name||'').trim(),email=cleanEmail(b.email),password=String(b.password||'');
    if(name.length<2||!email.includes('@')||password.length<8)return json(res,400,{ok:false,error:'Nome, e-mail válido e senha com pelo menos 8 caracteres são obrigatórios.'});
    try { const hash=hashPassword(password); const r=db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,\'aluno\')').run(name,email,hash); const id=Number(r.lastInsertRowid); db.prepare('INSERT INTO profiles(user_id) VALUES(?)').run(id); return json(res,201,{ok:true,message:'Conta de aluno criada. Agora faça login.'}); } catch(e){return json(res,409,{ok:false,error:'Este e-mail já está cadastrado.'})}
  }
  if(url==='/api/auth/login'&&method==='POST'){
    const b=await readBody(req),email=cleanEmail(b.email),password=String(b.password||''); const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);
    if(!u||!u.active||!verifyPassword(password,u.password_hash))return json(res,401,{ok:false,error:'E-mail ou senha inválidos.'});
    db.prepare('DELETE FROM sessions WHERE expires_at<=?').run(Date.now()); const token=crypto.randomBytes(32).toString('hex'); const days=Number(process.env.SESSION_DAYS||7); db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)').run(tokenHash(token),u.id,Date.now()+days*86400000);
    return json(res,200,{ok:true,user:publicUser(u)},{'Set-Cookie':`rb_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${days*86400}`});
  }
  if(url==='/api/auth/logout'&&method==='POST'){const t=parseCookies(req).rb_session;if(t)db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(t));return json(res,200,{ok:true},{'Set-Cookie':'rb_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'});}
  if(url==='/api/me'&&method==='GET'){const u=requireAuth(req,res);if(!u)return;return json(res,200,dashboardData(u));}
  if(url==='/api/ai/chat'&&method==='POST'){const u=requireAuth(req,res);if(!u)return;const b=await readBody(req);return json(res,200,{ok:true,reply:await aiReply(u,b.message)});}
  if(url==='/api/attendance/checkin'&&method==='POST'){const u=requireAuth(req,res);if(!u)return;db.prepare('INSERT INTO attendance(user_id) VALUES(?)').run(u.id);return json(res,201,{ok:true,message:'Check-in registrado!'})}
  if(url==='/api/student/evaluations'&&method==='GET'){const u=requireAuth(req,res);if(!u)return;return json(res,200,{evaluations:db.prepare('SELECT id,weight,waist,hip,notes,created_at FROM evaluations WHERE user_id=? ORDER BY id DESC LIMIT 24').all(u.id)})}
  if(url==='/api/exercises'&&method==='GET'){const u=requireAuth(req,res);if(!u)return;return json(res,200,{exercises:db.prepare('SELECT id,name,muscle_group,video_url,instructions FROM exercises ORDER BY name').all()})}
  if(url==='/api/calendar'&&method==='GET'){const u=requireAuth(req,res);if(!u)return;return json(res,200,{events:db.prepare('SELECT id,title,event_date,notes FROM calendar_events WHERE user_id IS NULL OR user_id=? ORDER BY event_date LIMIT 50').all(u.id)})}
  if(url==='/api/admin/evaluation'&&method==='POST'){const u=requireAuth(req,res,'admin');if(!u)return;const b=await readBody(req);const id=Number(b.user_id);if(!id)return json(res,400,{ok:false,error:'Aluno inválido'});db.prepare('INSERT INTO evaluations(user_id,weight,waist,hip,notes) VALUES(?,?,?,?,?)').run(id,Number(b.weight)||0,Number(b.waist)||0,Number(b.hip)||0,String(b.notes||''));if(Number(b.weight)>0)db.prepare('UPDATE profiles SET weight=? WHERE user_id=?').run(Number(b.weight),id);return json(res,201,{ok:true})}
  if(url==='/api/admin/exercise'&&method==='POST'){const u=requireAuth(req,res,'admin');if(!u)return;const b=await readBody(req);if(!b.name)return json(res,400,{ok:false,error:'Nome do exercício é obrigatório'});db.prepare('INSERT INTO exercises(name,muscle_group,video_url,instructions) VALUES(?,?,?,?)').run(String(b.name),String(b.muscle_group||''),String(b.video_url||''),String(b.instructions||''));return json(res,201,{ok:true})}
  if(url==='/api/admin/automation'&&method==='POST'){const u=requireAuth(req,res,'admin');if(!u)return;const b=await readBody(req);const key=String(b.key||'').slice(0,60);if(!key)return json(res,400,{ok:false,error:'Automação inválida'});db.prepare('INSERT INTO automations(key,enabled,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET enabled=excluded.enabled,updated_at=CURRENT_TIMESTAMP').run(key,b.enabled?1:0);return json(res,200,{ok:true})}
  if(url==='/api/admin/automations'&&method==='GET'){const u=requireAuth(req,res,'admin');if(!u)return;return json(res,200,{automations:db.prepare('SELECT key,enabled,updated_at FROM automations ORDER BY key').all()})}
  if(url==='/api/admin/stats'&&method==='GET'){const u=requireAuth(req,res,'admin');if(!u)return;return json(res,200,{students:db.prepare("SELECT COUNT(*) c FROM users WHERE role='aluno' AND active=1").get().c,pending:db.prepare("SELECT COUNT(*) c FROM payments WHERE status='pendente'").get().c,checkins:db.prepare("SELECT COUNT(*) c FROM attendance WHERE checkin_at>=datetime('now','-7 day')").get().c,overdue:db.prepare("SELECT COUNT(*) c FROM payments WHERE status='pendente' AND due_date<date('now')").get().c})}
  if(url==='/api/admin/students'&&method==='GET'){const u=requireAuth(req,res,'admin');if(!u)return;const rows=db.prepare(`SELECT u.id,u.name,u.email,u.active,p.goal,p.weight,p.height,(SELECT COUNT(*) FROM attendance a WHERE a.user_id=u.id) attendance,(SELECT status FROM payments x WHERE x.user_id=u.id ORDER BY x.id DESC LIMIT 1) payment_status FROM users u LEFT JOIN profiles p ON p.user_id=u.id WHERE u.role='aluno' ORDER BY u.name`).all();return json(res,200,{students:rows})}
  if(url==='/api/admin/student'&&method==='POST'){const u=requireAuth(req,res,'admin');if(!u)return;const b=await readBody(req);const id=Number(b.id);if(!id)return json(res,400,{ok:false,error:'Aluno inválido'});if(b.goal!==undefined||b.weight!==undefined||b.height!==undefined)db.prepare('UPDATE profiles SET goal=COALESCE(?,goal),weight=COALESCE(?,weight),height=COALESCE(?,height) WHERE user_id=?').run(b.goal??null,Number(b.weight)||0,Number(b.height)||0,id);if(b.active!==undefined)db.prepare('UPDATE users SET active=? WHERE id=? AND role=\'aluno\'').run(b.active?1:0,id);return json(res,200,{ok:true})}
  if(url==='/api/admin/workout'&&method==='POST'){const u=requireAuth(req,res,'admin');if(!u)return;const b=await readBody(req);const id=Number(b.user_id), title=String(b.title||'Treino RB'), objective=String(b.objective||''), exercises=Array.isArray(b.exercises)?b.exercises:[];if(!id)return json(res,400,{ok:false,error:'Aluno inválido'});db.prepare('DELETE FROM workouts WHERE user_id=?').run(id);db.prepare('INSERT INTO workouts(user_id,title,objective,exercises_json) VALUES(?,?,?,?)').run(id,title,objective,JSON.stringify(exercises));return json(res,201,{ok:true})}
  if(url==='/api/admin/payment'&&method==='POST'){const u=requireAuth(req,res,'admin');if(!u)return;const b=await readBody(req);const id=Number(b.user_id),amount=Number(b.amount)||0,due=String(b.due_date||'');if(!id||!due)return json(res,400,{ok:false,error:'Aluno e vencimento são obrigatórios'});db.prepare('INSERT INTO payments(user_id,amount,due_date,status) VALUES(?,?,?,?)').run(id,amount,due,b.status==='pago'?'pago':'pendente');return json(res,201,{ok:true})}
  if(url==='/api/admin/announcement'&&method==='POST'){const u=requireAuth(req,res,'admin');if(!u)return;const b=await readBody(req);if(!b.title||!b.body)return json(res,400,{ok:false,error:'Título e texto são obrigatórios'});db.prepare('INSERT INTO announcements(title,body) VALUES(?,?)').run(String(b.title),String(b.body));return json(res,201,{ok:true})}
  if(url==='/api/announcements'&&method==='GET'){const u=requireAuth(req,res);if(!u)return;return json(res,200,{announcements:db.prepare('SELECT id,title,body,created_at FROM announcements ORDER BY id DESC LIMIT 20').all()})}
  return json(res,404,{ok:false,error:'Rota não encontrada'});
}

const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.jpg':'image/jpeg','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon','.webmanifest':'application/manifest+json; charset=utf-8'};
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
    if(url.pathname.startsWith('/api/')) return await api(req,res,url.pathname);
    let pathname=decodeURIComponent(url.pathname); if(pathname==='/')pathname='/index.html'; const file=path.join(PUBLIC,pathname); if(!file.startsWith(PUBLIC))return json(res,403,{error:'Forbidden'});
    fs.stat(file,(err,st)=>{if(err||!st.isFile())return json(res,404,{error:'Not found'});res.writeHead(200,{'Content-Type':MIME[path.extname(file)]||'application/octet-stream','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin','X-Frame-Options':'SAMEORIGIN','Permissions-Policy':'camera=(),microphone=(),geolocation=()','Cache-Control':pathname.includes('assets/')?'public,max-age=86400':'no-cache'});fs.createReadStream(file).pipe(res)});
  }catch(e){console.error(e);json(res,500,{ok:false,error:'Erro interno'});}
});
const PORT=Number(process.env.PORT||3000);server.listen(PORT,()=>console.log(`RB Academia em http://localhost:${PORT}`));
