# RB Academia — V3 PWA + gestão + RB IA

Sistema preparado para GitHub e uso no Android como **PWA instalável**. O GitHub guarda o código; o servidor Node executa o backend e o banco. GitHub Pages sozinho não executa o backend.

## Recursos
- Login seguro e cadastro público sempre como `aluno`.
- Papel `admin` criado apenas pelo servidor.
- Painel administrativo protegido no backend.
- Avaliações físicas e evolução.
- Gráficos de evolução no painel do aluno.
- Biblioteca de exercícios com vídeos educativos externos.
- Calendário e notificações do navegador.
- Link para WhatsApp.
- RB IA conectada ao contexto autorizado do aluno (objetivo, treino, frequência, avaliação), sem senha.
- Painel de automações com liga/desliga.
- PWA: pode ser instalado no Android pelo Chrome quando publicado em HTTPS.
- Service Worker para cache básico e abertura rápida.

## Segurança
Nunca coloque senhas, tokens de WhatsApp, chave de IA ou credenciais no frontend. Use `.env` no servidor. O cadastro público força `role='aluno'` no servidor e todas as rotas `/api/admin/*` verificam a sessão e o papel no backend.

## Rodar localmente
Node.js 22.5+:

```bash
RB_ADMIN_EMAIL='dona@rbacademia.com.br' RB_ADMIN_PASSWORD='Troque123!' node server.js
```

Abra `http://localhost:3000`.

## GitHub + Android
1. Crie um repositório privado no GitHub e envie os arquivos.
2. Hospede o backend Node em um serviço que execute Node (por exemplo Render, Railway ou VPS).
3. Para produção, use PostgreSQL/Supabase em vez do SQLite local quando o host não tiver disco persistente.
4. Configure HTTPS e os segredos no painel do host.
5. Abra a URL HTTPS no Chrome do Android e use **Adicionar à tela inicial/Instalar app**.

> O projeto atual usa SQLite para desenvolvimento/testes. Não versione `data/rb-academia.db`.

## IA real
Configure no servidor:
- `AI_API_URL`
- `AI_API_KEY`
- `AI_MODEL`

A chave fica somente no servidor.

## WhatsApp
O botão abre o WhatsApp. Para automações de mensagens em produção, use a WhatsApp Business Platform/API oficial e mantenha tokens somente no servidor.
