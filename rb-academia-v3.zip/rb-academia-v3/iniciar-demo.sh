#!/usr/bin/env bash
set -e
RB_ADMIN_EMAIL='dona@rbacademia.local' RB_ADMIN_PASSWORD='Troque123!' PORT=3000 node server.js
